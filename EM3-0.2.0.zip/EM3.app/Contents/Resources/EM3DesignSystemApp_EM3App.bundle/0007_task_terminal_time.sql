ALTER TABLE tasks
    RENAME COLUMN completed_at TO terminal_at;

UPDATE tasks
SET terminal_at = updated_at
WHERE status = 'cancelled' AND terminal_at IS NULL;
