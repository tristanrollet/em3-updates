CREATE TABLE tasks (
    id TEXT PRIMARY KEY NOT NULL,
    parent_id TEXT REFERENCES tasks(id) ON DELETE RESTRICT,
    title TEXT NOT NULL CHECK(length(trim(title)) > 0),
    notes TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL CHECK(status IN ('open', 'in_progress', 'waiting', 'done', 'cancelled')),
    priority TEXT CHECK(priority IN ('low', 'medium', 'high')),
    scheduled_date TEXT,
    deadline TEXT,
    sort_order REAL NOT NULL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    deleted_at REAL,
    CHECK(parent_id IS NULL OR parent_id <> id)
);

CREATE INDEX tasks_parent_id_index ON tasks(parent_id);
CREATE INDEX tasks_schedule_index ON tasks(deleted_at, status, scheduled_date, sort_order);

CREATE TABLE task_tags (
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    name TEXT NOT NULL COLLATE NOCASE,
    PRIMARY KEY(task_id, name)
);

CREATE TABLE task_people (
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    person_id TEXT NOT NULL REFERENCES people(id) ON DELETE RESTRICT,
    PRIMARY KEY(task_id, person_id)
);

CREATE TABLE task_teams (
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE RESTRICT,
    PRIMARY KEY(task_id, team_id)
);

CREATE TABLE task_projects (
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
    PRIMARY KEY(task_id, project_id)
);

CREATE TABLE task_pull_requests (
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    pull_request_id TEXT NOT NULL REFERENCES pull_requests(id) ON DELETE RESTRICT,
    PRIMARY KEY(task_id, pull_request_id)
);

CREATE TABLE task_provider_links (
    id TEXT PRIMARY KEY NOT NULL,
    task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    label TEXT NOT NULL,
    url TEXT NOT NULL
);

CREATE TABLE task_workspace (
    singleton INTEGER PRIMARY KEY NOT NULL CHECK(singleton = 1),
    current_task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL
);

INSERT INTO task_workspace(singleton, current_task_id) VALUES (1, NULL);

CREATE TRIGGER tasks_reject_parent_cycle_on_insert
BEFORE INSERT ON tasks
WHEN NEW.parent_id IS NOT NULL
BEGIN
    SELECT CASE WHEN EXISTS (
        WITH RECURSIVE ancestors(id) AS (
            SELECT NEW.parent_id
            UNION ALL
            SELECT tasks.parent_id
            FROM tasks
            JOIN ancestors ON tasks.id = ancestors.id
            WHERE tasks.parent_id IS NOT NULL
        )
        SELECT 1 FROM ancestors WHERE id = NEW.id
    ) THEN RAISE(ABORT, 'a task cannot be its own ancestor') END;
END;

CREATE TRIGGER tasks_reject_parent_cycle_on_update
BEFORE UPDATE OF parent_id ON tasks
WHEN NEW.parent_id IS NOT NULL
BEGIN
    SELECT CASE WHEN EXISTS (
        WITH RECURSIVE ancestors(id) AS (
            SELECT NEW.parent_id
            UNION ALL
            SELECT tasks.parent_id
            FROM tasks
            JOIN ancestors ON tasks.id = ancestors.id
            WHERE tasks.parent_id IS NOT NULL
        )
        SELECT 1 FROM ancestors WHERE id = NEW.id
    ) THEN RAISE(ABORT, 'a task cannot be its own ancestor') END;
END;

CREATE TRIGGER tasks_clear_current_on_terminal_update
AFTER UPDATE OF status, deleted_at ON tasks
WHEN NEW.status IN ('done', 'cancelled') OR NEW.deleted_at IS NOT NULL
BEGIN
    UPDATE task_workspace
    SET current_task_id = NULL
    WHERE singleton = 1 AND current_task_id = NEW.id;
END;
