ALTER TABLE tasks
    ADD COLUMN completed_at REAL;

UPDATE tasks
SET completed_at = updated_at
WHERE status = 'done';
