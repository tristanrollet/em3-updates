ALTER TABLE tracker_items
    ADD COLUMN external_id TEXT;

ALTER TABLE tracker_items
    ADD COLUMN issue_type TEXT NOT NULL DEFAULT '';

ALTER TABLE tracker_items
    ADD COLUMN status_category TEXT NOT NULL DEFAULT 'unknown'
    CHECK (status_category IN ('backlog', 'in_progress', 'review', 'done', 'unknown'));

ALTER TABLE tracker_items
    ADD COLUMN parent_epic_id TEXT REFERENCES tracker_items(id) ON DELETE SET NULL;

CREATE INDEX tracker_items_parent_epic_id_index
    ON tracker_items(parent_epic_id);

CREATE UNIQUE INDEX tracker_items_provider_external_id_unique
    ON tracker_items(provider_id, external_id)
    WHERE provider_id IS NOT NULL AND external_id IS NOT NULL;
