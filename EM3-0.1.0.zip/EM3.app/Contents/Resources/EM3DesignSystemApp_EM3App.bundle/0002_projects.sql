CREATE TABLE projects (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL CHECK (length(trim(name)) > 0),
    description TEXT NOT NULL,
    start_date TEXT,
    target_date TEXT,
    quarter TEXT NOT NULL,
    status TEXT NOT NULL CHECK (
        status IN ('preparing', 'stalled', 'in_progress', 'in_review', 'released', 'postponed')
    ),
    deleted_at REAL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE project_people (
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    person_id TEXT NOT NULL REFERENCES people(id) ON DELETE RESTRICT,
    PRIMARY KEY (project_id, person_id)
);

CREATE INDEX project_people_person_id_index
    ON project_people(person_id);

CREATE TABLE project_teams (
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE RESTRICT,
    PRIMARY KEY (project_id, team_id)
);

CREATE INDEX project_teams_team_id_index
    ON project_teams(team_id);

CREATE TABLE project_reference_types (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL COLLATE NOCASE UNIQUE CHECK (length(trim(name)) > 0),
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE project_references (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    reference_type_id TEXT NOT NULL REFERENCES project_reference_types(id) ON DELETE RESTRICT,
    label TEXT NOT NULL,
    url TEXT NOT NULL CHECK (length(trim(url)) > 0),
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE INDEX project_references_project_id_index
    ON project_references(project_id);

CREATE TABLE tracker_items (
    id TEXT PRIMARY KEY NOT NULL,
    provider_id TEXT,
    key TEXT NOT NULL CHECK (length(trim(key)) > 0),
    item_type TEXT NOT NULL DEFAULT 'epic',
    title TEXT NOT NULL,
    status TEXT NOT NULL,
    url TEXT NOT NULL,
    refreshed_at REAL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE project_tracker_items (
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    tracker_item_id TEXT NOT NULL REFERENCES tracker_items(id) ON DELETE CASCADE,
    PRIMARY KEY (project_id, tracker_item_id)
);

CREATE INDEX project_tracker_items_tracker_item_id_index
    ON project_tracker_items(tracker_item_id);
