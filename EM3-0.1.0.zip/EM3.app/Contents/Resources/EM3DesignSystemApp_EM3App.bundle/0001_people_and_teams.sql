CREATE TABLE teams (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL COLLATE NOCASE UNIQUE CHECK (length(trim(name)) > 0),
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE app_state (
    singleton INTEGER PRIMARY KEY NOT NULL CHECK (singleton = 1),
    current_team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE RESTRICT
);

CREATE TABLE people (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL CHECK (length(trim(name)) > 0),
    role TEXT NOT NULL,
    email TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('active', 'away', 'archived')),
    birthday TEXT,
    company_start_date TEXT,
    github_username TEXT,
    next_one_on_one_at REAL,
    deleted_at REAL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE team_memberships (
    id TEXT PRIMARY KEY NOT NULL,
    person_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
    team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE RESTRICT,
    start_date REAL NOT NULL,
    end_date REAL
);

CREATE INDEX team_memberships_person_id_index
    ON team_memberships(person_id);

CREATE INDEX team_memberships_team_id_index
    ON team_memberships(team_id);
