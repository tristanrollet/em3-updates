CREATE TABLE pull_request_repositories (
    id TEXT PRIMARY KEY NOT NULL,
    provider TEXT NOT NULL,
    external_id TEXT NOT NULL,
    owner TEXT NOT NULL,
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    is_selected INTEGER NOT NULL DEFAULT 1,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    UNIQUE(provider, external_id)
);

CREATE TABLE pull_requests (
    id TEXT PRIMARY KEY NOT NULL,
    repository_id TEXT NOT NULL REFERENCES pull_request_repositories(id) ON DELETE CASCADE,
    external_id TEXT NOT NULL,
    number INTEGER NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    url TEXT NOT NULL,
    author_login TEXT NOT NULL,
    author_person_id TEXT REFERENCES people(id) ON DELETE SET NULL,
    state TEXT NOT NULL,
    is_draft INTEGER NOT NULL DEFAULT 0,
    head_sha TEXT,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    etag TEXT,
    provider_created_at REAL NOT NULL,
    provider_updated_at REAL NOT NULL,
    last_refreshed_at REAL NOT NULL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    UNIQUE(repository_id, external_id)
);

CREATE INDEX pull_requests_repository_id_idx ON pull_requests(repository_id);
CREATE INDEX pull_requests_project_id_idx ON pull_requests(project_id);
CREATE INDEX pull_requests_author_person_id_idx ON pull_requests(author_person_id);
CREATE INDEX pull_requests_provider_updated_at_idx ON pull_requests(provider_updated_at DESC);

CREATE TABLE pull_request_labels (
    pull_request_id TEXT NOT NULL REFERENCES pull_requests(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    color_hex TEXT,
    PRIMARY KEY(pull_request_id, name)
);

CREATE TABLE pull_request_participants (
    pull_request_id TEXT NOT NULL REFERENCES pull_requests(id) ON DELETE CASCADE,
    login TEXT NOT NULL,
    person_id TEXT REFERENCES people(id) ON DELETE SET NULL,
    role TEXT NOT NULL,
    review_state TEXT,
    submitted_at REAL,
    PRIMARY KEY(pull_request_id, login, role)
);

CREATE INDEX pull_request_participants_person_id_idx
    ON pull_request_participants(person_id);

CREATE TABLE pull_request_ci_jobs (
    id TEXT PRIMARY KEY NOT NULL,
    pull_request_id TEXT NOT NULL REFERENCES pull_requests(id) ON DELETE CASCADE,
    external_id TEXT NOT NULL,
    source TEXT NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL,
    conclusion TEXT,
    details_url TEXT,
    started_at REAL,
    completed_at REAL,
    UNIQUE(pull_request_id, source, external_id)
);

CREATE INDEX pull_request_ci_jobs_pull_request_id_idx
    ON pull_request_ci_jobs(pull_request_id);
